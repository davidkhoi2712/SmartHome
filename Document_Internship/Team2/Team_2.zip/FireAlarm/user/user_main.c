#include "esp_common.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "uart.h"
#include "gpio.h"
#include "esp_system.h"
#include "ds18b20.h"
#include "lwip/err.h"
#include "lwip/sockets.h"
#include "lwip/sys.h"
#include "lwip/netdb.h"
#include "lwip/dns.h"
#include "espconn.h"

#define WEB_SERVER "192.168.5.1"

int r, i;
uint8_t addr[8], data[12];
const char ssid[32] = "test";
const char password[64] = "123123123";
bool x = 0;
static char path[300];
int bit = 0;
int key = 0;
int set = 2;
char digit[10];
int templimit = 100;
int gaslimit = 600;

struct tem{
	int whole;
	int fract;
	uint8 check;
};

void wifiConnection(){
	struct station_config *sta_conf = (struct station_config *) malloc(sizeof(struct station_config));;
	memcpy(sta_conf->ssid, ssid, 32);
	memcpy(sta_conf->password, password, 64);
	sta_conf->bssid_set = 0x00;
	struct ip_addr ip;
	struct ip_info ip1;
	IP4_ADDR(&ip, 192,168,5,102);
	ip1.ip = ip;
	IP4_ADDR(&ip, 192,168,5,1);
	ip1.gw = ip;
	IP4_ADDR(&ip, 255,255,255,0);
	ip1.netmask = ip;
	wifi_station_dhcpc_stop();
	wifi_set_ip_info(0x00, &ip1);
	wifi_station_set_config(sta_conf);
	wifi_station_set_auto_connect(0x01);
	free(sta_conf);
}

struct tem readTemp(){
	uint8 w = 1;
	ds_init();
	r = ds_search(addr);
	//if (!r) w = 0;
	//if(!ds_reset()) w = 0;
	ds_reset();
	ds_select(addr);
	ds_write(DS1820_CONVERT_T, 1);
	os_delay_us(1000);
	//if(!ds_reset()) w = 0;
	ds_reset();
	ds_select(addr);
	ds_write(DS1820_READ_SCRATCHPAD, 0);  
	for(i = 0; i < 9; i++)
	{
		data[i] = ds_read();
	}
	if (crc8(data,8)!=data[8]){
		w = 0;
	}
	int hight, low, tread, sign, whole, fract;
	low = data[0];
	hight = data[1];
	tread = (hight << 8) + low;
	sign = tread & 0x8000;
	//if (sign) w = 0;
	whole = tread >> 4;  
	fract = (tread & 0xf) * 100 / 16;
	struct tem rs = {
		.whole = whole,
		.fract = fract,
		.check = w,
	};
	return rs;
}

void run(){
	int i = 0;
		for (i = 0;i < 30;i++){
			GPIO_OUTPUT_SET(5, 0);
			os_delay_us(2300);
			GPIO_OUTPUT_SET(5, 1);
			os_delay_us(2300);
			GPIO_OUTPUT_SET(5, 0);
			os_delay_us(15400);
		}
		for (i = 0;i < 30;i++){
			GPIO_OUTPUT_SET(5, 0);
			os_delay_us(600);
			GPIO_OUTPUT_SET(5, 1);
			os_delay_us(600);
			GPIO_OUTPUT_SET(5, 0);
			os_delay_us(18800);
		}
}

int http_get(){
	if (wifi_station_get_connect_status()==STATION_GOT_IP){
		struct addrinfo* hints = (struct addrinfo *) malloc(sizeof(struct addrinfo));
		hints->ai_family = AF_UNSPEC;
		hints->ai_socktype = SOCK_STREAM;
		struct addrinfo *res;
		int err = getaddrinfo(WEB_SERVER, "80", hints, &res);
		free(hints);
		if (err != 0 || res == NULL){
			if (res) freeaddrinfo(res);
			printf("1\n");
			return 1;
		}
		int s = socket(res->ai_family, res->ai_socktype, 0);
		if (s < 0){
			freeaddrinfo(res);
			printf("2\n");
			return 1;
		}
		err = connect(s, res->ai_addr, res->ai_addrlen);
		if (err != 0){
			close(s);
            freeaddrinfo(res);
			printf("3\n");
			return 1;
		}
		freeaddrinfo(res);
		err = write(s, path, strlen(path));
		if (err < 0 ){
			close(s);
			printf("4\n");
			return 1;
		}
		int r = 0;
		char *recv_buf = (char *)malloc(sizeof(char)*300);
		for (i = 0; i<300;i++){
			recv_buf[i] = 0;
		}
		read(s, recv_buf, 299);
		printf("%s\n",recv_buf);
		if (recv_buf[0]=='?'){
			free(recv_buf);
			close(s);
			return 1;
		}
		for (i = 205;i<300;i++){
			if (isdigit(recv_buf[i])){
				r = r*10 + recv_buf[i] - '0';
			}else{
				break;
			}
		}
		i += 4;
		gaslimit = 0;
		templimit = 0;
		int* p = &gaslimit;
		while (r > 0){
			if (isdigit(recv_buf[i])){
				if (p == &set){
					set = 0;
				}
				*p = (*p)*10 + recv_buf[i] - '0';
			}else{
				if (p == &templimit){
					p = &set;
				}else{
					p = &templimit;
				}
			}
			i++;
			r--;
		}
		free(recv_buf);
		close(s);
	}
	return 0;
}

void readSS(void *pvParameters)
{
    for(;;){
		int gas = system_adc_read();
		//printf("gas = %d\n",gas);
		struct tem temp;
		do{
			temp = readTemp();
			os_delay_us(1000);
		}while(!temp.check);
		//printf("temp = %d.%d\n", temp.whole ,temp.fract);
		if ((gas>gaslimit || temp.whole >= templimit)&&(gaslimit != 0 && templimit != 0)){
			key = 1;
		}else{
			key = 0;
		}
		strcpy(path,"GET /add.php?tem=");
		for (i = 0;i<10;i++){
			digit[i] = 0;
		}
		sprintf(digit,"%d",temp.whole);
		strcat(path, digit);
		strcat(path, ".");
		sprintf(digit,"%d",temp.fract);
		strcat(path, digit);
		strcat(path,"&gas=");
		sprintf(digit,"%d",gas);
		strcat(path, digit);
		strcat(path," HTTP/1.1\r\nHost: autofirealarm.ddns.net\r\nUser-Agent: esp-open-rtos/0.1 esp8266\r\nConnection: close\r\n\r\n");
		if ((set == 2 && key == 1) || (set == 3)){
			strcat(path,".");
		}
		http_get();
		vTaskDelay(100);
    }
}

void alarm(void *pvParameters)
{
    for(;;){
		if ((set == 2 && key == 1) || (set == 3)){
			run();
			bit ^= 1;
			GPIO_OUTPUT_SET(4, bit);
		}
		vTaskDelay(1);
    }
}

bool pre = 0;

void control(void *pvParameters)
{
	GPIO_OUTPUT_SET(0,1);
	gpio16_output_conf();
    for(;;){
		if (!GPIO_INPUT_GET(0)){
			if (!pre){
				pre = 1;
				gpio16_output_set(set==2);
				set = (set==2?1:2);
			}
		}else{
			pre = 0;
		}
		if (set == 1){
			gpio16_output_set(1);
		}else{
			gpio16_output_set(0);
		}
		vTaskDelay(1);
    }
}

void user_init(void)
{
    UART_ConfigTypeDef uart_config;
    uart_config.baud_rate    = BIT_RATE_115200;
    uart_config.data_bits     = UART_WordLength_8b;
    uart_config.parity          = USART_Parity_None;
    uart_config.stop_bits     = USART_StopBits_1;
    uart_config.flow_ctrl      = USART_HardwareFlowControl_None;
    uart_config.UART_RxFlowThresh = 120;
    uart_config.UART_InverseMask = UART_None_Inverse;
    UART_ParamConfig(UART0, &uart_config);
	
	wifi_set_opmode(0x01);
	wifiConnection();
	
	xTaskCreate(alarm, "alarm", 256, NULL, 1, NULL);
    xTaskCreate(readSS, "readSS", 256, NULL, 2, NULL);
	xTaskCreate(control, "control", 256, NULL, 1, NULL);
}
