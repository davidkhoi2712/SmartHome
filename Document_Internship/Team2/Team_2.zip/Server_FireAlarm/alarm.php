<?php
	wincache_ucache_set("control","3");
	header("Location: ./index.php");
?>