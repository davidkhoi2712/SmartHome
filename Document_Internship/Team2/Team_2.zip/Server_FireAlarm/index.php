<!DOCTYPE HTML>
<html>
<head>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
</head>

<body>
<script type="text/javascript" src="js/materialize.min.js"></script>
<script>
  function resizeIframe(obj) {
    obj.style.height = (obj.contentWindow.document.body.scrollHeight) + 'px';
  }
</script>
<script>
        function refreshIFrame() {
            var x = document.getElementById("frame");
            x.contentWindow.location.reload();
            var t = setTimeout(refreshIFrame, 1000);
        }
</script>
<iframe id='' src='./chart_tem.php' width='100%' frameborder='0' scrolling='no' onload='resizeIframe(this)'></iframe>
<iframe id='' src='./chart_gas.php' width='100%' frameborder='0' scrolling='no' onload='resizeIframe(this)'></iframe>
<form method="GET" action="set.php">
	<div class="row">
		<div class="input-field col s3">
			<input id="gas" name="gas" min="200" max="1024" type="number" class="validate" value="<?php echo wincache_ucache_get("gas"); ?>">
			<label for="gas"> Gas limit </label>
		</div>
		<div class="input-field col s3">
			<input id="temp" name="temp" min="25" max="300" type="number" class="validate" value="<?php echo wincache_ucache_get("temp"); ?>">
			<label for="temp"> Temp limit </label>
		</div>
		<button class="btn waves-effect waves-light" type="submit" name="action" style="margin-top='20px'"> Set
			<i class="material-icons right">send</i>
		</button>
	</div>
</form>

<a class='btn yellow darken-4 col s3' href='./delete.php' >Clear chart</a>
<a class='btn blue lighten-1 col s3' href='./on.php' >Auto</a>
<a class='btn red col s3' href='./off.php' >Off</a>
<a class='btn red col s3' href='./alarm.php' >Alarm</a>
</body>
</html>