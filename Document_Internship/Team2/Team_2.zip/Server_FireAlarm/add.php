<?php
	$filename = "tem.txt";  
	$file = fopen( $filename, "a+" ); 
	fwrite( $file, "{y: " . $_GET["tem"] . " },\r\n");
	fclose( $file );
	
	$filename = "gas.txt";  
	$file = fopen( $filename, "a+" ); 
	fwrite( $file, "{y: " . $_GET["gas"] . " },\r\n");
	fclose( $file );
	
	echo wincache_ucache_get("gas").";";
	echo wincache_ucache_get("temp").";";
	
	if (wincache_ucache_exists("control")){
		echo wincache_ucache_get("control");
		wincache_ucache_delete("control");
	}
?>