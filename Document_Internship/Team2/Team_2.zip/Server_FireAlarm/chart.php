<script>
window.onload = function () {
	run1();
}

function run1(){
	run();
	window.setTimeout(run2, 1000);
}

function run2(){
	run();
	window.setTimeout(run1, 1000);
}

function run() { 
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			document.getElementById("text").innerHTML = this.responseText;
		}
	};
	xhttp.open("GET", "chart_gas.php", true);
	xhttp.send();
}
</script>
<body id="text">
	
</body>