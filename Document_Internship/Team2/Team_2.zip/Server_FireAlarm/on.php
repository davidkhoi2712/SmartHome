<?php
	wincache_ucache_set("control","2");
	header("Location: ./index.php");
?>