<?php
	wincache_ucache_set("control","1");
	header("Location: ./index.php");
?>