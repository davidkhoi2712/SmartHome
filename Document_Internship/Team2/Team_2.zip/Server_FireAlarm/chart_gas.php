<!DOCTYPE HTML>
<?php
	$page = $_SERVER['PHP_SELF'];
	$sec = "1";
?>
<html>
<head>  
	<meta http-equiv="refresh" content="<?php echo $sec?>;URL='<?php echo $page?>'">
<script>
window.onload = function () {

var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: false,
	theme: "light2",
	title:{
		text: "Gas Chart"
	},
	axisY:{
		includeZero: false
	},
	data: [{        
		type: "line",       
		dataPoints: [
			<?php
				$filename = "gas.txt";  
				$file = fopen( $filename, "r" ); 
				$filesize = filesize( $filename );
				$filetext = fread( $file, $filesize );
				if (strlen($filetext) < 300){
					echo $filetext;
				}else{
					$text = substr($filetext, strlen($filetext)-300, 300);
					while($text[0]!="{"){
						$text = substr($text,1);
					}
					echo $text;
				}
				fclose( $file );
			?>
		]
	}]
});
chart.render();

}
</script>
</head>
<body>
<div id="chartContainer" style="height: 300px; width: 100%;"></div>
<script src="./canvasjs.min.js"></script>
</body>
</html>