<?php
	if (strlen($_GET["gas"]) > 0 && strlen($_GET["temp"]) > 0){
		wincache_ucache_set("gas", $_GET["gas"]);
		wincache_ucache_set("temp", $_GET["temp"]);
	}
	header("Location: ./index.php");
?>