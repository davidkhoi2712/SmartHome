<?php
	unlink('tem.txt');
	unlink('gas.txt');
	header("Location: ./index.php");
?>