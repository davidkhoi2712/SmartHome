# Tác vụ cơ bản với ESP8266

Hướng dẫn cụ thể: https://esp8266.vn/freertos-sdk/basic/basic-task/

Tài nguyên hỗ trợ cho dự án https://esp8266.vn
