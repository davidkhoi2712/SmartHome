#include "esp_common.h"
#include "uart.h"
#include "gpio.h"
#include "esp_system.h"
#include "ds18b20.h"

static unsigned char address[8];
static uint8_t LastDiscrepancy;
static uint8_t LastFamilyDiscrepancy;
static uint8_t LastDeviceFlag;

void ds_init()
{
	PIN_FUNC_SELECT(DS18B20_MUX,  DS18B20_FUNC);
	PIN_PULLUP_EN(DS18B20_MUX);
	GPIO_DIS_OUTPUT(DS18B20_PIN);
	ds_reset_search();
}

int ds_search(uint8_t *newAddr)
{
	uint8_t id_bit_number;
	uint8_t last_zero, rom_byte_number;
	uint8_t id_bit, cmp_id_bit;
	int search_result;
	int i;

	unsigned char rom_byte_mask, search_direction;

	id_bit_number = 1;
	last_zero = 0;
	rom_byte_number = 0;
	rom_byte_mask = 1;
	search_result = 0;

	if (!LastDeviceFlag)
	{
		if (!ds_reset())
		{
			LastDiscrepancy = 0;
			LastDeviceFlag = FALSE;
			LastFamilyDiscrepancy = 0;
			return FALSE;
		}

		ds_write(DS1820_SEARCHROM, 0);

		do
		{
			id_bit = ds_read_bit();
			cmp_id_bit = ds_read_bit();
	 
			if ((id_bit == 1) && (cmp_id_bit == 1))
				break;
			else
			{
				if (id_bit != cmp_id_bit)
					search_direction = id_bit; 
				else
				{
					if (id_bit_number < LastDiscrepancy)
						search_direction = ((address[rom_byte_number] & rom_byte_mask) > 0);
					else
						search_direction = (id_bit_number == LastDiscrepancy);

					if (search_direction == 0)
					{
						last_zero = id_bit_number;

						if (last_zero < 9)
							LastFamilyDiscrepancy = last_zero;
					}
				}

				if (search_direction == 1)
					address[rom_byte_number] |= rom_byte_mask;
				else
					address[rom_byte_number] &= ~rom_byte_mask;

				ds_write_bit(search_direction);

				id_bit_number++;
				rom_byte_mask <<= 1;

				if (rom_byte_mask == 0)
				{
					rom_byte_number++;
					rom_byte_mask = 1;
				}
			}
		}
		while(rom_byte_number < 8);

		if (!(id_bit_number < 65))
		{
			LastDiscrepancy = last_zero;

			if (LastDiscrepancy == 0)
				LastDeviceFlag = TRUE;

			search_result = TRUE;
		}
	}

	if (!search_result || !address[0])
	{
		LastDiscrepancy = 0;
		LastDeviceFlag = FALSE;
		LastFamilyDiscrepancy = 0;
		search_result = FALSE;
	}
	for (i = 0; i < 8; i++) newAddr[i] = address[i];
	return search_result;
}

void ds_select(const uint8_t *rom)
{
	uint8_t i;
	ds_write(DS1820_MATCHROM, 0);
	for (i = 0; i < 8; i++) ds_write(rom[i], 0);
}

void ds_skip()
{
    ds_write(DS1820_SKIP_ROM,0);
}

void ds_reset_search()
{
	int i;
	LastDiscrepancy = 0;
	LastDeviceFlag = FALSE;
	LastFamilyDiscrepancy = 0;
	for(i = 7; ; i--) {
		address[i] = 0;
		if ( i == 0) break;
	}
}

uint8_t ds_reset(void)
{
	int r;
	uint8_t retries = 125;
	GPIO_DIS_OUTPUT(DS18B20_PIN);
	do {
		if (--retries == 0) return 0;
		os_delay_us(2);
	} while ( !GPIO_INPUT_GET(DS18B20_PIN));
	GPIO_OUTPUT_SET(DS18B20_PIN, 0);
	os_delay_us(500);
	GPIO_DIS_OUTPUT(DS18B20_PIN);
	os_delay_us(65);
	r = !GPIO_INPUT_GET(DS18B20_PIN);
	os_delay_us(490);
	return r;
}

void ds_write(uint8_t v, int power)
{
	uint8_t bitMask;
	for (bitMask = 0x01; bitMask; bitMask <<= 1) {
		ds_write_bit((bitMask & v)?1:0);
	}
	if (!power) {
		GPIO_DIS_OUTPUT(DS18B20_PIN);
		GPIO_OUTPUT_SET(DS18B20_PIN, 0);
	}
}

void ds_write_bit(int v)
{
	GPIO_OUTPUT_SET(DS18B20_PIN, 0);
	if(v) {
		os_delay_us(10);
		GPIO_OUTPUT_SET(DS18B20_PIN, 1);
		os_delay_us(55);
	} else {
		os_delay_us(65);
		GPIO_OUTPUT_SET(DS18B20_PIN, 1);
		os_delay_us(5);
	}
}

uint8_t ds_read()
{
	uint8_t bitMask;
	uint8_t r = 0;
	for (bitMask = 0x01; bitMask; bitMask <<= 1) {
		if ( ds_read_bit()) r |= bitMask;
	}
	return r;
}

int ds_read_bit(void)
{
	int r;
	GPIO_OUTPUT_SET(DS18B20_PIN, 0);
	os_delay_us(3);
	GPIO_DIS_OUTPUT(DS18B20_PIN);
	os_delay_us(10);
	r = GPIO_INPUT_GET(DS18B20_PIN);
	os_delay_us(53);
	return r;
}

uint8_t crc8(const uint8_t *addr, uint8_t len)
{
	uint8_t crc = 0;
	uint8_t i;
	while (len--) {
		uint8_t inbyte = *addr++;
		for (i = 8; i; i--) {
			uint8_t mix = (crc ^ inbyte) & 0x01;
			crc >>= 1;
			if (mix) crc ^= 0x8C;
			inbyte >>= 1;
		}
	}
	return crc;
}

uint16_t crc16(const uint16_t *data, const uint16_t  len)
{
	uint16_t  i;
	uint16_t  crc = 0;
    for ( i = 0; i < len; i++) {
    	uint16_t cdata = data[len];
    	cdata = (cdata ^ (crc & 0xff)) & 0xff;
    	crc >>= 8;
    	if (oddparity[cdata & 0xf] ^ oddparity[cdata >> 4])
    		crc ^= 0xc001;
    	cdata <<= 6;
    	crc ^= cdata;
    	cdata <<= 1;
    	crc ^= cdata;
    }
    return crc;
}
