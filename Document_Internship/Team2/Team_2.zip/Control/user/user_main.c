#include "esp_common.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "uart.h"
#include "gpio.h"
#include "esp_system.h"
#include "ds18b20.h"
#include "lwip/err.h"
#include "lwip/sockets.h"
#include "lwip/sys.h"
#include "lwip/netdb.h"
#include "lwip/dns.h"
#include "espconn.h"

//#define WEB_SERVER "autofirealarm.ddns.net"

int i = 0;
const char ssid[32] = "HTC_M9";
const char password[64] = "123123123";
char *path[4];
char *rec[4];
const char *host[4] = {"smartlight.ddns.net","autofirealarm.ddns.net","maylanh102.000webhostapp.com","dooriot.000webhostapp.com"};
char digit[10];
int key[4] = {0,0,0,0};
char hot[1] = "!";
char fake[1] = "?";
bool alarm = 0;
int lock = 0;
int count = 1;

struct espconn esp_conn;
esp_tcp esptcp;

void tcp_server_sent_cb(void *arg)
{
   //data sent successfully
 
    //printf("tcp sent cb \r\n");
}
 
void tcp_server_recv_cb(void *arg, char *pusrdata, unsigned short length)
{
   //received some data from tcp connection
   int i;
   struct espconn *pespconn = arg;
   uint8 *ip = pespconn->proto.tcp->remote_ip;
   printf("%d.%d.%d.%d\n", ip[0],ip[1],ip[2],ip[3]);
   if (ip[3] == 102){
		key[1] = 1;
		strcpy(path[1], pusrdata);
		if (strlen(rec[1])==0){
			espconn_sent(pespconn, fake, strlen(fake));
		}else{
			espconn_sent(pespconn, rec[1], strlen(rec[1]));
		}
		printf("%d,%d\n",ip[3],strlen(rec[1]));
		if (pusrdata[strlen(pusrdata)-1]=='.'){
			alarm = 1;
		}else{
			alarm = 0;
		}
		strcpy(rec[1],"?");
   }
   if (ip[3] == 101){
	    key[0] = 1;
	    stpcpy(path[0], pusrdata);
	    if (alarm){
			espconn_sent(pespconn, hot, strlen(hot));
	    }else{
			if (strlen(rec[0])==0){
				espconn_sent(pespconn, fake, strlen(fake));
			}else{
				espconn_sent(pespconn, rec[0], strlen(rec[0]));
			}
	    }
	    printf("%d,%d\n",ip[3],strlen(rec[0]));
	    strcpy(rec[0],"?");
   }
   if (ip[3] == 103){
	    key[2] = 1;
	    stpcpy(path[2], pusrdata);
	    if (alarm){
			espconn_sent(pespconn, hot, strlen(hot));
	    }else{
			if (strlen(rec[2])==0){
				espconn_sent(pespconn, fake, strlen(fake));
			}else{
				espconn_sent(pespconn, rec[2], strlen(rec[2]));
			}
	    }
	    printf("%d,%d\n",ip[3],strlen(rec[2]));
	    strcpy(rec[2],"?");
   }
   if (ip[3] == 104){
	    key[3] = 1;
	    stpcpy(path[3], pusrdata);
	    if (alarm){
			espconn_sent(pespconn, hot, strlen(hot));
	    }else{
			if (strlen(rec[3])==0){
				espconn_sent(pespconn, fake, strlen(fake));
			}else{
				espconn_sent(pespconn, rec[3], strlen(rec[3]));
			}
	    }
	    printf("%d,%d\n",ip[3],strlen(rec[3]));
	    strcpy(rec[3],"?");
   }
}

void tcp_server_discon_cb(void *arg)
{
   //tcp disconnect successfully
    
    //printf("tcp disconnect succeed !!! \r\n");
}
 
void tcp_server_recon_cb(void *arg, sint8 err)
{
   //error occured , tcp connection broke. 
    
    //printf("reconnect callback, error code %d !!! \r\n",err);
}
 
 
void tcp_server_listen(void *arg)
{
    struct espconn *pesp_conn = arg;
    printf("tcp_server_listen !!! \r\n");
    espconn_regist_recvcb(pesp_conn, tcp_server_recv_cb);
    espconn_regist_reconcb(pesp_conn, tcp_server_recon_cb);
    espconn_regist_disconcb(pesp_conn, tcp_server_discon_cb);
    espconn_regist_sentcb(pesp_conn, tcp_server_sent_cb);
}

void user_tcpserver_init()
{
    esp_conn.type = ESPCONN_TCP;
    esp_conn.state = ESPCONN_NONE;
    esp_conn.proto.tcp = &esptcp;
    esp_conn.proto.tcp->local_port = 80;
    espconn_regist_connectcb(&esp_conn, tcp_server_listen);
 
    sint8 ret = espconn_accept(&esp_conn);
     
    printf("espconn_accept [%d] !!! \r\n", ret);
 
}

void wifiConnection(){
	struct station_config *sta_conf = (struct station_config *) malloc(sizeof(struct station_config));;
	memcpy(sta_conf->ssid, ssid, 32);
	memcpy(sta_conf->password, password, 64);
	sta_conf->bssid_set = 0x00;
	wifi_station_set_config(sta_conf);
	wifi_station_set_auto_connect(0x01);
	free(sta_conf);
}

int http_get(const char* host, char* path,uint8 ip){
	int i;
	if (wifi_station_get_connect_status()==STATION_GOT_IP){
		struct addrinfo* hints = (struct addrinfo *) malloc(sizeof(struct addrinfo));
		hints->ai_family = AF_UNSPEC;
		hints->ai_socktype = SOCK_STREAM;
		struct addrinfo *res;
		int err = getaddrinfo(host, "80", hints, &res);
		free(hints);
		if (err != 0 || res == NULL){
			if (res) freeaddrinfo(res);
			printf("1\n");
			return 1;
		}
		int s = socket(res->ai_family, res->ai_socktype, 0);
		if (s<0){
			freeaddrinfo(res);
			printf("2\n");
			return 1;
		}
		err = connect(s, res->ai_addr, res->ai_addrlen);
		if (err != 0){
			close(s);
            freeaddrinfo(res);
			printf("3\n");
			return 1;
		}
		freeaddrinfo(res);
		err = write(s, path, strlen(path));
		if (err < 0 ){
			close(s);
			printf("4\n");
			return 1;
		}
		int r = 0;
		char *recv_buf = (char *)malloc(sizeof(char)*300);
		for (i = 0; i<300;i++){
			recv_buf[i] = 0;
		}
		read(s, recv_buf, 299);
		strcpy(rec[ip-101], recv_buf);
		free(recv_buf);
		close(s);
	}
	return 0;
}

void readSS(void *pvParameters)
{
    for(;;){
		if (key[1]){
			http_get(host[1],path[1],102);
			key[1] = 0;
		}
		if (key[0]){
			http_get(host[0],path[0],101);
			key[0] = 0;
		}
		if (key[2]){
			http_get(host[2],path[2],103);
			key[2] = 0;
		}
		if (key[3]){
			http_get(host[3],path[3],104);
			key[3] = 0;
		}
		vTaskDelay(1);
    }
}

void server_start(){
	struct softap_config *config = (struct softap_config *) zalloc(sizeof(struct softap_config));
    wifi_softap_get_config(config);
    sprintf(config->ssid, "test");
    sprintf(config->password, "123123123");
    config->authmode = AUTH_WPA_WPA2_PSK;
    config->ssid_len = 0;
    config->max_connection = 4;
    wifi_softap_set_config(config);
	free(config);
	wifi_softap_dhcps_stop();
    struct ip_info *info = (struct ip_info *) malloc(sizeof(struct ip_info));
    IP4_ADDR(&info->ip, 192, 168, 5, 1);
    IP4_ADDR(&info->gw, 192, 168, 5, 1);
    IP4_ADDR(&info->netmask, 255, 255, 255, 0);
    wifi_set_ip_info(SOFTAP_IF, info);
	free(info);
    struct dhcps_lease *dhcp_lease = (struct dhcps_lease *) malloc(sizeof(struct dhcps_lease));
    IP4_ADDR(&dhcp_lease->start_ip, 192, 168, 5, 100);
    IP4_ADDR(&dhcp_lease->end_ip, 192, 168, 5, 105);
    wifi_softap_set_dhcps_lease(dhcp_lease);
    wifi_softap_dhcps_start();
	free(dhcp_lease);
}

void user_init(void)
{
    UART_ConfigTypeDef uart_config;
    uart_config.baud_rate    = BIT_RATE_115200;
    uart_config.data_bits     = UART_WordLength_8b;
    uart_config.parity          = USART_Parity_None;
    uart_config.stop_bits     = USART_StopBits_1;
    uart_config.flow_ctrl      = USART_HardwareFlowControl_None;
    uart_config.UART_RxFlowThresh = 120;
    uart_config.UART_InverseMask = UART_None_Inverse;
    UART_ParamConfig(UART0, &uart_config);
	
	wifi_set_opmode(0x03);
	server_start();
	espconn_init();
	wifiConnection();
	int i;
	for (i = 0;i<4;i++){
		path[i] = (char*)malloc(sizeof(char)*300);
		path[i][0] = 0;
		rec[i] = (char*)malloc(sizeof(char)*300);
		strcpy(rec[i],"?");
	}
	
	user_tcpserver_init();
	
    xTaskCreate(readSS, "readSS", 256, NULL, 2, NULL);
}
